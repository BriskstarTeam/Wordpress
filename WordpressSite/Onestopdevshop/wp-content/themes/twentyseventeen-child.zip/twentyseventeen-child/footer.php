<?php wp_footer(); ?>
<div id="10seos-badge" class="verified-icon" data-company-id="389245"></div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="footer_section">
  <div class="container">
    <div class="wrapper top">
      <div class="content _25">
        <div id="footer-widgets">
          <div class="widget-column footer-widget-1">
            <?php dynamic_sidebar( 'footer-1' ); ?>
          </div></div>
      </div>
      <div class="content _25">
        <div id="footer-widgets">
             <div id="footer-widget1">
               <div class="widget-column footer-widget-1">
                 <?php dynamic_sidebar( 'footer-2' ); ?>
               </div>
             </div>
         </div>
       </div>
      <div class="content _25">
        <div class="widget-column footer-widget-1">
          <?php dynamic_sidebar( 'footer-3' ); ?>
        </div>
      </div>
      <div class="content _25">
        <div id="footer-widgets">
             <div id="footer-widget1">
               <div class="widget-column footer-widget-1">
                 <?php dynamic_sidebar( 'footer-4' ); ?>
               </div>
             </div>
         </div>
      </div>
    </div>
    <hr>
    <div class="footer-div">
                  <div>
                     <b><p >Made with <span><i class="fa fa-heart red" aria-hidden="true"></i></span> in <span id="spin"></span></p></b>
                     <div class="below-link">
                        <p>OneStopDevShop © <?php echo date('Y');?> </p>
                        <p> // </p>
                        <a href="<?php echo home_url(); ?>/privacy/" target="_blank">Privacy Policy</a>
                     </div>
                  </div>
                  <div>
                     <ul class="socila-links">
                        <li><a href="https://www.facebook.com/groups/softwarestartupsgrowthhiring" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="https://twitter.com/geordiewardman" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href=" https://www.linkedin.com/in/geordiewardman/" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                     </ul>
                  </div>
               </div>
  </div>
</div>

<!-- <script type="text/javascript">
$(document).ready(function() {
    // Configure/customize these variables.
    var showChar = 300;  // How many characters are shown by default
    var ellipsestext = "...";
    var moretext = "more";
    var lesstext = "less";


    $('.more').each(function() {
        var content = $(this).html();

        if(content.length > showChar) {

            var c = content.substr(0, showChar);
            var h = content.substr(showChar, content.length - showChar);

            var html = c + '<span class="moreellipses">' + ellipsestext+ '&nbsp;</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<p class="more_btn1"><a href="" class="morelink">' + moretext + '</a></p></span>';

            $(this).html(html);
        }

    });

    $(".morelink").click(function(){
        if($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
        }
        $(this).parent().prev().toggle();
        $(this).prev().toggle();
        return false;
    });
});

</script> -->
<!--<script src="//www.socialintents.com/api/socialintents.1.3.js#2c9fa6c375fd16a001761eca79864812" async="async"></script>-->
<!--<script src="https://embed.small.chat/TFF4C144QG01GR6D4MA9.js" async></script>-->
</body>
</html>
