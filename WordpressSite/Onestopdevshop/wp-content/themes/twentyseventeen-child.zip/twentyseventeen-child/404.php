<?php

 get_header(); ?>
 <?php /*<!DOCTYPE html>
<html data-wf-page="5eb40071fa63c85922a62789" data-wf-site="5e8b4cfdbb73f603407121d1">
<head>
  <meta charset="utf-8">
  <title>404 Page</title>
  <meta content="On Time And On Budget, Or It’s On Us." name="description">
  <meta content="404 page" property="og:title">
  <meta content="On Time And On Budget, Or It’s On Us." property="og:description">
  <meta content="404 page" property="twitter:title">
  <meta content="On Time And On Budget, Or It’s On Us." property="twitter:description">
  <meta property="og:type" content="website">
  <meta content="summary_large_image" name="twitter:card">
  <meta content="width=device-width, initial-scale=1" name="viewport">
  <link href="<?php echo get_theme_file_uri(); ?>/assets/css/onestop-b2fbcd-product.css" rel="stylesheet" type="text/css">
  <style>@media (min-width:992px) {html.w-mod-js:not(.w-mod-ix) [data-w-id="dd9441a3-1997-af6b-7f7e-0ae5df339b82"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="f70ff7c1-45db-20b9-bfa2-81154d06c49d"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="c5775b65-6c0a-ff2d-94b3-8eadb482a0de"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="37d29402-8767-6202-cf1c-c9342efc42c5"] {-webkit-transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="cf10ba6e-791a-821b-5f88-21c6826cc28e"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}}@media (max-width:991px) and (min-width:768px) {html.w-mod-js:not(.w-mod-ix) [data-w-id="dd9441a3-1997-af6b-7f7e-0ae5df339b82"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="f70ff7c1-45db-20b9-bfa2-81154d06c49d"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="c5775b65-6c0a-ff2d-94b3-8eadb482a0de"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="37d29402-8767-6202-cf1c-c9342efc42c5"] {-webkit-transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="cf10ba6e-791a-821b-5f88-21c6826cc28e"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}}@media (max-width:767px) and (min-width:480px) {html.w-mod-js:not(.w-mod-ix) [data-w-id="dd9441a3-1997-af6b-7f7e-0ae5df339b82"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="f70ff7c1-45db-20b9-bfa2-81154d06c49d"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="c5775b65-6c0a-ff2d-94b3-8eadb482a0de"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="37d29402-8767-6202-cf1c-c9342efc42c5"] {-webkit-transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(18%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}html.w-mod-js:not(.w-mod-ix) [data-w-id="cf10ba6e-791a-821b-5f88-21c6826cc28e"] {-webkit-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-moz-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);-ms-transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);transform:translate3d(0%, 0%, 0) scale3d(0.7, 0.7, 1) rotateX(0) rotateY(0) rotateZ(26DEG) skew(0, 0);}}</style>
  <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
  <link href="<?php echo get_theme_file_uri(); ?>/assets/images/favicon.png" rel="shortcut icon" type="image/x-icon">
  <link href="<?php echo get_theme_file_uri(); ?>/assets/images/webclip.png" rel="apple-touch-icon">
</head>
<body>
 <div class="header-logo-wrap swing text-center pt-20 pb-10">
    <?php $custom_logo_id = get_theme_mod( 'custom_logo' );
          $logo = wp_get_attachment_image_src( $custom_logo_id ,'full');
     ?>
  	<a href="<?php echo get_site_url(); ?>"><img src="<?php echo $logo[0]; ?>" alt="<?php echo get_bloginfo( 'name' ); ?>" class="logo-img top"></a>
</div> */ ?>

<div class="wrap">
    <div id="primary" class="content-area">
        <main id="main" class="site-main" role="main">
            <div class="section pb-40">
                <div class="container">
                    <?php /* <div id="notfound">
                        <div class="notfound">
                            <div class="notfound-404">
                                <h1>Oops!</h1>
                            </div>
                            <h2>404 - Page not found</h2>
                            <p>The page you are looking for might have been removed had its name changed or is temporarily unavailable.</p>
                            <a class="btn w-button" href="<?php echo get_home_url(); ?>">Go To Homepage</a>
                        </div>
                    </div>  */ ?>
                    <div id="error-page">
                      <div class="error-page">
                        <h1>Oops!</h1>
                        <div class="margin-minus">
                            <img src="https://onestopdevshop.io/wp-content/uploads/2020/06/broken-pencil.svg" class="img-fluid">
                            <h2>404 Error</h2>
                            <h6>Sorry, Page Not Found</h6>
                            <p>Yikes, it looks like something's broken. But, you can always find your way back through one of these.</p>
                            <ul class="error-list">
                                <li><a href="<?php home_url(); ?>/geordie-wardman/">About Us </a></li>
                                <li><a href="<?php home_url(); ?>/podcasts/">Podcast </a></li>
                                <li><a href="<?php home_url(); ?>/blog/">Articles </a></li>
                                <li><a href="<?php home_url(); ?>/contact-us/">Contact Us</a></li>
                                <li><a href="<?php home_url(); ?>/portfolio/">Portfolio</a></li>
                            </ul>
                        </div>
                      </div>
                    </div>
                </div>
            </div>

        </main><!-- #main -->
    </div><!-- #primary -->
</div><!-- .wrap -->


<?php  get_footer(); ?>
