<?php
echo '<a href="'.get_author_posts_url($atts['user_id']).'" target="_blank" class="btn btn-default btn-flat">'.__('View All','wpuser').'</a>';
